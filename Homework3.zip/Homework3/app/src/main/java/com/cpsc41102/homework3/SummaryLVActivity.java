package com.cpsc41102.homework3;

import android.app.Activity;
import android.content.ContentValues;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.ListView;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.cpsc41102.homework3.adapter.SummaryLVAdapter;

import java.io.File;

public class SummaryLVActivity extends AppCompatActivity {

    protected ListView mSummaryView;
    protected Menu detailMenu;
    protected final String TAG = "Summary Screen";
    protected SummaryLVAdapter ad;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.summary_listview);
        //

        mSummaryView = findViewById(R.id.summary_list_view_id);

        ad = new SummaryLVAdapter(this);
        mSummaryView.setAdapter(ad);

        File dbFile = this.getDatabasePath("student.db");
        SQLiteDatabase db = SQLiteDatabase.openOrCreateDatabase(dbFile,null);

        db.execSQL("CREATE TABLE IF NOT EXISTS Student (FirstName Text, LastName Text, CWID Integer)");

        db.execSQL("DELETE FROM Student WHERE CWID=?", new String[]{"123456789"});
        db.execSQL("INSERT INTO Student VALUES ('Theresa', 'Tanubrata', 123456789)");


        db.execSQL("DELETE FROM Student WHERE CWID=?", new String[]{"234567891"});
        db.execSQL("INSERT INTO Student VALUES (?,?,?)", new String[]{"Regina", "Falange", "234567891"});

        db.delete("Student", "CWID=?", new String[]{"345678912"});
        ContentValues vals = new ContentValues();
        vals.put("FirstName", "James");
        vals.put("LastName", "Karaire");
        vals.put("CWID", "345678912");
        db.insert("Student", null, vals);

        Cursor cursor = db.query("Student", null, null, null, null, null, null);
        if(cursor.getCount() > 0){
            while (cursor.moveToNext()){
                String fName = cursor.getString(cursor.getColumnIndex("FirstName"));
                int cwid = cursor.getInt(cursor.getColumnIndex("CWID"));
                //
                Log.d("Database Log", fName + ": " + cwid);
            }
        }


        db.close();

    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.detail_screen_menu,menu);
        detailMenu = menu;
        menu.findItem(R.id.action_done).setVisible(false);
        menu.findItem(R.id.action_add).setVisible(true);
        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        if(item.getItemId() == R.id.action_add){
            Intent intent = new Intent(this, StudentDetailActivity.class);
            this.startActivity(intent);
        }

        return super.onOptionsItemSelected(item);
    }

    @Override
    protected void onStart() {
        Log.d(TAG, "onStart() called ");
        ad.notifyDataSetChanged();
        super.onStart();
    }

    @Override
    protected void onPause() {
        Log.d(TAG, "onPause() called ");
        super.onPause();
    }

    @Override
    protected void onStop() {
        Log.d(TAG, "onStop() called");
        super.onStop();
    }

    @Override
    protected void onResume() {
        Log.d(TAG, "onResume() called");
        super.onResume();
    }

    @Override
    protected void onDestroy() {
        Log.d(TAG, "onDestroy() called");
        super.onDestroy();
    }
}